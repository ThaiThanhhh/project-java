import os
import cv2
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import uuid
import json
import logging
import sys
import time

# Thiết lập logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('VideoAnalyzer')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['RESULTS_FOLDER'] = 'static/results'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB limit

# Tạo thư mục nếu chưa tồn tại
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULTS_FOLDER'], exist_ok=True)

def process_video(video_path, output_dir, session_id, frame_interval=0.5):
    """Xử lý video và trả về kết quả phân tích"""
    results = {
        'session_id': session_id,
        'video_info': {},
        'frames': [],
        'summary': {
            'recommendations': ["Chế độ phân tích đơn giản: Chỉ trích xuất frame"]
        }
    }
    
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"Không thể mở video: {video_path}")
            return None
        
        # Lấy thông tin video
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        
        results['video_info'] = {
            'fps': fps,
            'total_frames': total_frames,
            'duration': duration,
            'filename': os.path.basename(video_path)
        }
        
        # Xử lý từng frame
        frame_count = 0
        saved_count = 0
        frame_interval_count = max(1, int(fps * frame_interval)) if fps > 0 else 30
        
        logger.info(f"Bắt đầu xử lý video. Tổng frame: {total_frames}, Khoảng frame: {frame_interval_count}")
        
        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                break
                
            if frame_count % frame_interval_count == 0:
                frame_time = frame_count / fps if fps > 0 else frame_count
                minutes = int(frame_time // 60)
                seconds = int(frame_time % 60)
                timestamp = f"{minutes:02d}:{seconds:02d}"
                
                # Lưu frame
                frame_filename = f"frame_{saved_count:04d}.jpg"
                frame_path = os.path.join(output_dir, frame_filename)
                
                # Ghi chú thời gian lên frame
                annotated_frame = frame.copy()
                cv2.putText(annotated_frame, f"Frame: {frame_count}", (10, 30), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.putText(annotated_frame, timestamp, (10, 60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                
                cv2.imwrite(frame_path, annotated_frame)
                
                # Lưu thông tin frame
                frame_data = {
                    'frame_number': frame_count,
                    'timestamp': timestamp,
                    'frame_path': os.path.join('results', session_id, frame_filename)
                }
                results['frames'].append(frame_data)
                
                saved_count += 1
            
            frame_count += 1
            if frame_count % 100 == 0:
                logger.info(f"Đã xử lý {frame_count}/{total_frames} frame")
        
        cap.release()
        logger.info(f"Xử lý video hoàn tất. Số frame đã lưu: {saved_count}")
        return results
    
    except Exception as e:
        logger.error(f"Lỗi xử lý video: {e}")
        return None

@app.route('/', methods=['GET'])
def index():
    """Trang chủ tải lên video"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    """Xử lý yêu cầu phân tích video"""
    try:
        if 'video' not in request.files:
            return redirect(request.url)
        
        video_file = request.files['video']
        if video_file.filename == '':
            return redirect(request.url)
        
        # Tạo session ID duy nhất
        session_id = str(uuid.uuid4())
        session_dir = os.path.join(app.config['RESULTS_FOLDER'], session_id)
        os.makedirs(session_dir, exist_ok=True)
        
        # Lưu video
        video_ext = os.path.splitext(video_file.filename)[1].lower()
        if video_ext not in ['.mp4', '.mov', '.avi']:
            return "Định dạng video không hỗ trợ. Vui lòng chọn file MP4, MOV hoặc AVI.", 400
            
        video_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{session_id}{video_ext}")
        video_file.save(video_path)
        
        # Xử lý video
        logger.info(f"Bắt đầu xử lý video: {video_path}")
        start_time = time.time()
        results = process_video(
            video_path, 
            session_dir, 
            session_id,
            frame_interval=0.5  # 2 frame/giây
        )
        elapsed_time = time.time() - start_time
        logger.info(f"Thời gian xử lý: {elapsed_time:.2f} giây")
        
        if not results:
            return "Lỗi khi xử lý video", 500
        
        # Lưu kết quả
        results_path = os.path.join(session_dir, 'results.json')
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Kết quả đã lưu tại: {results_path}")
        return redirect(url_for('results', session_id=session_id))
    
    except Exception as e:
        logger.error(f"Lỗi trong quá trình phân tích: {e}")
        return "Đã xảy ra lỗi nội bộ", 500

@app.route('/results/<session_id>')
def results(session_id):
    """Hiển thị kết quả phân tích"""
    try:
        session_dir = os.path.join(app.config['RESULTS_FOLDER'], session_id)
        results_path = os.path.join(session_dir, 'results.json')
        
        if not os.path.exists(results_path):
            return "Kết quả không tồn tại", 404
        
        # Đọc kết quả
        with open(results_path, 'r', encoding='utf-8') as f:
            results = json.load(f)
        
        return render_template('results.html', results=results, session_id=session_id)
    
    except Exception as e:
        logger.error(f"Lỗi hiển thị kết quả: {e}")
        return "Đã xảy ra lỗi khi đọc kết quả", 500

@app.route('/frame/<session_id>/<frame_name>')
def get_frame(session_id, frame_name):
    """Phục vụ frame đã phân tích"""
    try:
        return send_from_directory(
            os.path.join(app.config['RESULTS_FOLDER'], session_id), 
            frame_name
        )
    except Exception as e:
        logger.error(f"Lỗi khi truy xuất frame: {e}")
        return "Không tìm thấy frame", 404

if __name__ == '__main__':
    print("=" * 50)
    print("ỨNG DỤNG PHÂN TÍCH VIDEO")
    print("=" * 50)
    print("🖥  Ứng dụng đang khởi động...")
    print("🌐  Truy cập: http://localhost:5000")
    print("⚠️  Lưu ý: Đây là phiên bản đơn giản, chỉ trích xuất frame")
    app.run(host='0.0.0.0', port=5000, debug=True)